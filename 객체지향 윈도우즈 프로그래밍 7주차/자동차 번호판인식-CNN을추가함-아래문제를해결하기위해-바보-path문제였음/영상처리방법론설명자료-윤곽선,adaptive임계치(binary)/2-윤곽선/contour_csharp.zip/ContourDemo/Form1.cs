﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContourDemo {
	public partial class Form1 : Form {
		/*public int[][] picture = {
			new int[] { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
			new int[] { 0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0 },
			new int[] { 0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0 },
			new int[] { 0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0 },
			new int[] { 0,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,1,0,0 },
			new int[] { 0,1,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0 },
			new int[] { 0,1,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0 },
			new int[] { 0,1,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0 },
			new int[] { 0,1,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0 },
			new int[] { 0,1,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0 },
			new int[] { 0,1,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,1,0,0 },
			new int[] { 0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0 },
			new int[] { 0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0 },
			new int[] { 0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0 },
			new int[] { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
			new int[] { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 }
		};
		*/

		Bitmap picture;// = (Bitmap)Image.FromFile("./2.png");
		int[,] binary;

		public Form1(Bitmap img, string caption) {
			this.picture = img;
			this.binary = this.Img2Bin(this.picture, 1);
			c = new Contour(this.binary);
			InitializeComponent();
			this.Text = caption;
			//this.ClientSize = this.picture.Size;
		}

		public int GetGray(Bitmap img, int x, int y) {
			Color p = img.GetPixel(x,y);
			return (p.R + p.G + p.B) / 3;
		}

		public int[,] Img2Bin(Bitmap img, int threshold) {
			int[,] ret = new int[img.Height, img.Width];
			for(int i = 0; i < img.Height; ++i) {
				for(int j = 0; j < img.Width; ++j) {
					ret[i,j] = GetGray(img, j, i) >= threshold ? 1 : 0;
				}
			}
			return ret;
		}

		public Bitmap Bin2Img(int[,] bin) {
			Bitmap map = new Bitmap(bin.GetLength(1), bin.GetLength(0));
			for(int i = 0; i < bin.GetLength(0); ++i) {
				for(int j = 0; j < bin.GetLength(1); ++j) {
					Color c = Color.Black;
					if(bin[i,j] == 0) {
						c = Color.Black;
					}
					else if(bin[i,j] == 1) {
						c = Color.White;
					}
					else {
						Random r = new Random(Math.Abs(bin[i,j]));
						c = Color.FromArgb(r.Next(0,255), r.Next(0,255), r.Next(0,255));
					}
					map.SetPixel(j, i, c);
				}
			}
			return map;
		}

		private void Form1_Paint(object sender, PaintEventArgs e) {

			if(this.picture.Width <= 30 && this.picture.Height <= 30) {
				/*SolidBrush whitebrush = new SolidBrush(Color.White);
				SolidBrush redbrush = new SolidBrush(Color.Red);
				SolidBrush blackbrush = new SolidBrush(Color.Black);
				SolidBrush graybrush = new SolidBrush(Color.Gray);
				Pen gpen = new Pen(new SolidBrush(Color.Gray));
				Font font = new Font(FontFamily.GenericSansSerif, 10);

				int fheight = this.binary.GetLength(0);
				int cell_height = this.ClientSize.Height / fheight;

				for(int y = 0; y < this.binary.GetLength(0); ++y) {
					int fwidth = this.binary.GetLength(1);
					int cell_width = this.ClientSize.Width / fwidth;
					for(int x = 0; x < fwidth; ++x) {
						int start_x = cell_width * x;
						int start_y = cell_height * y;
						Rectangle cell_rect = new Rectangle(start_x, start_y, cell_width, cell_height);
						if(this.binary[y,x] == 0) {
							if(CheckPoint(x, y)) {
								e.Graphics.FillRectangle(redbrush, cell_rect);
							}
							else {
								e.Graphics.FillRectangle(graybrush, cell_rect);
							}
							e.Graphics.DrawString(this..m[y, x].ToString(), font, blackbrush, start_x + 5, start_y + 5);
						}
						else {
							if(CheckPoint(x,y)) {
								e.Graphics.FillRectangle(redbrush, cell_rect);
							}
							else {
								e.Graphics.FillRectangle(whitebrush, cell_rect);
							}
							//e.Graphics.DrawString(this.binary[y,x].ToString(), font, blackbrush, start_x + 10, start_y + 10);
							e.Graphics.DrawString(this.p.m[y,x].ToString(), font, blackbrush, start_x + 5, start_y + 5);
						}
						e.Graphics.DrawRectangle(gpen, cell_rect);
					}
				}*/
			}
			else {
				e.Graphics.DrawImage(this.picture, 0, 0);
				if(this.c.frameBorder != null) {
					this.c.frameBorder.DrawBorder(e.Graphics);
				}
			}
		}

		Contour c;

		private void Form1_KeyDown(object sender, KeyEventArgs e) {
			if(e.KeyCode == Keys.Enter) {
				//this.t = new Thread(new ThreadStart(this.ThreadWork));
				//this.t.Start();
				c.RasterScan();
				//this.InterestPoints = p.Detect(0);
				//this.binary = p.f;
				//this.picture = Bin2Img(this.binary);
			}
			this.Invalidate();
		}
	}
}
