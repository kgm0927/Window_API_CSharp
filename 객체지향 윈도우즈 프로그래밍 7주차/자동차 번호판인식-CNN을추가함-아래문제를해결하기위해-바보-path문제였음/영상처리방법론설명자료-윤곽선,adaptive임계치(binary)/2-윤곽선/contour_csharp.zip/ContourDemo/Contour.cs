﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContourDemo {
	public class Contour {
		
		public int[,] f;
		int NBD = 1;
		int LNBD = 1;

		public class Border {
			public bool isHoleBorder = false;
			public int NBD = 1;
			public int LNBD = 1;
			public Rectangle Rect = new Rectangle();
			public Border Parent;
			public List<Border> Children = new List<Border>();
			//public List<Point> BorderPoints = new List<Point>();
			//public Point[] 
			public Color PersonalColor;

			public Border(int NBD, int i, int j) {
				this.NBD = NBD;
				this.Rect.X = j;
				this.Rect.Y = i;
				Random r = new Random(this.NBD);
				PersonalColor = Color.FromArgb(r.Next(0,255), r.Next(0,255), r.Next(0,255));
			}

			public void Append(Border b) {
				this.Children.Add(b);
				b.Parent = this;
			}

			public Border GetRoot() {
				if(this.Parent == null) return this;
				else return this.Parent.GetRoot();
			}

			public void AddBorderPoints(int i, int j) {
				//this.BorderPoints.Add(new Point(j, i));
				int pdi = this.Rect.Height;
				int pdj = this.Rect.Width;
				int di = Math.Abs(this.Rect.Y - i);
				int dj = Math.Abs(this.Rect.X - j);

				if(i < this.Rect.Y) {
					this.Rect.Y = i;
					this.Rect.Height += di;
				}
				if(j < this.Rect.X) {
					this.Rect.X = j;
					this.Rect.Width += dj;
				}
				if(pdi < di) {
					this.Rect.Height = i - this.Rect.Y;
				}
				if(pdj < dj) {
					this.Rect.Width = j - this.Rect.X;
				}
			}

			Font f = new Font(FontFamily.GenericMonospace,9);

			public void DrawBorder(Graphics g) {
				//Border root = GetRoot();
				//int wt = width / root.Rect.Width;
				//int ht = height / root.Rect.Height;
				
				Pen p = new Pen(PersonalColor, 2);
				Rectangle rt = new Rectangle(this.Rect.Location, this.Rect.Size);
				//rt.X *= wt;
				//rt.Y *= ht;
				//rt.Width *= wt;
				//rt.Height *= ht;
				g.DrawRectangle(p, rt);
				g.DrawString((this.isHoleBorder ? "[Hole]" : "[Outer]") + "NBD : " + this.NBD, f, new SolidBrush(PersonalColor), rt.X, rt.Y + (this.isHoleBorder ? 10 : 0));
				if(this.Parent != null) {
					g.DrawString("Parent : " + this.Parent.NBD, f, new SolidBrush(this.Parent.PersonalColor), rt.X, rt.Y + (this.isHoleBorder ? 20 : 10));
				}
				for(int i = 0; i < this.Children.Count; ++i) {
					this.Children[i].DrawBorder(g);
				}
			}
		}

		public Contour(int[,] picture) {
			this.f = picture;
		}

		public Point GetNextClockwise(int i, int j, int i2, int j2, bool counter = false) {
			Point ret = new Point(-1, -1);

			int di = i2 - i;
			int dj = j2 - j;

			if(counter) {
				if(di < 0 && dj < 0) {
					ret.Y = i;
					ret.X = j - 1;
				}
				else if(di < 0 && dj == 0) {
					ret.Y = i - 1;
					ret.X = j - 1;
				}
				else if(di < 0 && dj > 0) {
					ret.Y = i - 1;
					ret.X = j;
				}
				else if(di == 0 && dj < 0) {
					ret.Y = i + 1;
					ret.X = j - 1;
				}
				else if(di == 0 && dj > 0) {
					ret.Y = i - 1;
					ret.X = j + 1;
				}
				else if(di > 0 && dj < 0) {
					ret.Y = i + 1;
					ret.X = j;
				}
				else if(di > 0 && dj == 0) {
					ret.Y = i + 1;
					ret.X = j + 1;
				}
				else if(di > 0 && dj > 0) {
					ret.Y = i;
					ret.X = j + 1;
				}
			}
			else  {
				if(di < 0 && dj < 0) {
					ret.Y = i - 1;
					ret.X = j;
				}
				else if(di < 0 && dj == 0) {
					ret.Y = i - 1;
					ret.X = j + 1;
				}
				else if(di < 0 && dj > 0) {
					ret.Y = i;
					ret.X = j + 1;
				}
				else if(di == 0 && dj < 0) {
					ret.Y = i - 1;
					ret.X = j - 1;
				}
				else if(di == 0 && dj > 0) {
					ret.Y = i + 1;
					ret.X = j + 1;
				}
				else if(di > 0 && dj < 0) {
					ret.Y = i;
					ret.X = j - 1;
				}
				else if(di > 0 && dj == 0) {
					ret.Y = i + 1;
					ret.X = j - 1;
				}
				else if(di > 0 && dj > 0) {
					ret.Y = i + 1;
					ret.X = j;
				}
			}

			return ret;
		}

		public int GetValue(Point pos) {
			return GetValue(pos.Y, pos.X);
		}

		public int GetValue(int i, int j) {
			if(i < 0) i = 0;
			if(j < 0) j = 0;
			return f[i,j];
		}

		public void SetValue(int i, int j, int v) {
			if(i < 0) i = 0;
			if(j < 0) j = 0;
			f[i,j] = v;
		}

		public Point GetNextNonzeroClockwise(int i, int j, int i2, int j2, bool counter = false) {
			Point ret = new Point(-1, -1);
			for(int k = 0; k < 8; ++k) {
				Point cur = GetNextClockwise(i, j, i2, j2, counter);
				int temp = this.f[cur.Y, cur.X];
				this.f[cur.Y, cur.X] = -1;
				this.f[cur.Y, cur.X] = temp;
				if(GetValue(cur) != 0) {
					ret = cur;
					break;
				}
				i2 = cur.Y;
				j2 = cur.X;
			}
			return ret;
		}

		public Border frameBorder;

		public Border FollowBorder(int i, int j, int i2, int j2) {
			Border ret = new Border(NBD, i, j);
			ret.LNBD = LNBD;
			int i1;
			int j1;
			int i3 = i;
			int j3 = j;
			int i4;
			int j4;

			//3.1
			Point p = GetNextNonzeroClockwise(i, j, i2, j2);
			if(p.X == -1 && p.Y == -1) {
				f[i,j] = NBD * -1;
				//goto 4
			}
			else {
				j1 = p.X;
				i1 = p.Y;
				//3.2
				i2 = i1;
				j2 = j1;
				i3 = i;
				j3 = j;
				while(true) {
					//3.3
					p = GetNextNonzeroClockwise(i3, j3, i2, j2, true);
					j4 = p.X;
					i4 = p.Y;
					//3.4
					if(GetValue(i3, j3+1) == 0) {
						SetValue(i3, j3, NBD * -1);
						ret.AddBorderPoints(i3, j3);
					}
					else if(GetValue(i3, j3+1) != 0 && GetValue(i3, j3) == 1) {
						SetValue(i3, j3, NBD);
						ret.AddBorderPoints(i3, j3);
					}
					//3.5
					if(i4 == i && j4 == j && i3 == i1 && j3 == j1) {
						//goto 4
						if(f[i,j] != 1) {
							ret.LNBD = Math.Abs(f[i,j]);
						}
						break;
					}
					else {
						i2 = i3;
						j2 = j3;
						i3 = i4;
						j3 = j4;
					}
				}
			}
			return ret;
		}

		public void RasterScan() {
			this.frameBorder = new Border(NBD, 0, 0);
			this.frameBorder.isHoleBorder = true;
			this.frameBorder.AddBorderPoints(f.GetLength(0), f.GetLength(1));
			Border lastBorder = this.frameBorder;
			for(int i = 0; i < f.GetLength(0); ++i) {
				LNBD = 1;
				for(int j = 0; j < f.GetLength(1); ++j) {
					if(f[i,j] == 1 && f[i,j - 1] == 0) { //Outer Border
						NBD++;
						int i2 = i;
						int j2 = j - 1;
						Border newb = FollowBorder(i, j, i2, j2);
						if(lastBorder.isHoleBorder) {
							lastBorder.Append(newb);
						}
						else {
							lastBorder.Parent.Append(newb);
						}
						lastBorder = newb;
					}
					else if(f[i,j] >= 1 && f[i,j + 1] == 0) { //Hole Border (innerBorder)
						NBD++;
						int i2 = i;
						int j2 = j + 1;
						if(f[i,j] > 1) {
							LNBD = f[i,j];
						}
						Border newb = FollowBorder(i, j, i2, j2);
						newb.isHoleBorder = true;
						if(lastBorder.isHoleBorder) {
							lastBorder.Parent.Append(newb);
						}
						else {
							lastBorder.Append(newb);
						}
						lastBorder = newb;
					}

					//4번
					if(GetValue(i, j) != 1) {
						LNBD = Math.Abs(GetValue(i, j));
					}
				}
			}
		}
	}
}
