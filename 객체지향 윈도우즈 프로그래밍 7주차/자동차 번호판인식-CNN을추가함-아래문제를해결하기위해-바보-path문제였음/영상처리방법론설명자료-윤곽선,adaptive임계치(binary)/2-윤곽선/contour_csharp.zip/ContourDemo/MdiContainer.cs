﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContourDemo {
	public partial class MdiContainer : Form {
		public MdiContainer() {
			this.dlg.InitialDirectory = Environment.CurrentDirectory;
			InitializeComponent();
		}

		OpenFileDialog dlg = new OpenFileDialog();

		private void 열기ToolStripMenuItem_Click(object sender, EventArgs e) {
			if(dlg.ShowDialog() == DialogResult.OK) {
				Bitmap img = (Bitmap)Image.FromFile(dlg.FileName);
				Form1 form = new Form1(img, dlg.FileName);
				form.MdiParent = this;
				form.Width = this.ClientSize.Width;
				form.Height = this.ClientSize.Height;
				form.Show();
			}
		}
	}
}
