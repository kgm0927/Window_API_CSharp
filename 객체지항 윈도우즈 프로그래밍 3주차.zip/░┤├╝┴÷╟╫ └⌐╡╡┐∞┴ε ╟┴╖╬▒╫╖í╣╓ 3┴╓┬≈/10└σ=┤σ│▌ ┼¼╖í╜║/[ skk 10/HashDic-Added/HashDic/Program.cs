﻿using System;
using System.Collections;

class CSTest
{
	static void Main()
	{
		Hashtable ht = new Hashtable();
		ht.Add("boy", "소년");
		ht.Add("girl", "소녀");
		ht["school"] = "학교";
		//Console.WriteLine(ht["boy"]);
		foreach (DictionaryEntry de in ht) 
		{
			Console.WriteLine("Key = {0}, Value = {1}", de.Key, de.Value);

		}

	}
}
