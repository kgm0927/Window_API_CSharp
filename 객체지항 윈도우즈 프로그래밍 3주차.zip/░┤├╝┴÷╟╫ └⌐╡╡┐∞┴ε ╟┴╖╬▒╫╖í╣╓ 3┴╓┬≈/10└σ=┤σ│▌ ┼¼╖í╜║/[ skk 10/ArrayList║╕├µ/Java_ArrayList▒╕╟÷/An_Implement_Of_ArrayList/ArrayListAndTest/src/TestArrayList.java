import _01_ArrayList.ArrayList;

public class TestArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Object> a= new ArrayList<Object>(3);
		a.add(2.4);
		a.add("string");
		a.add(365);
		
		a.add(2.4);
		a.add("string");
		a.add(365);
		
		a.add(2.4);
		a.add("string");
		a.add(365);
		
		a.add(2.4);
		a.add("string");
		a.add(365);
		
		for(int i=0; i<a.size(); i++) {
			System.out.println(a.get(i));
		}
	}

}
