﻿using System;
using System.Reflection;


class Time
{
	public int hour, min, sec;
	public Time(int h, int m, int s) { hour = h; min = m; sec = s; }
	/*
	public override bool Equals(object obj)
	{
		Time Other = (Time)obj;
		Console.WriteLine("Equals Called");
		return (Other.hour == hour && Other.min == min && Other.sec == sec);
	}
	//*/
	/*
	public override bool Equals(object obj)
	{
		if (obj == null || obj.GetType() != this.GetType()) return false;
		Time Other = (Time)obj;
		Console.WriteLine("Equals Called");
		return (Other.hour == hour && Other.min == min && Other.sec == sec);
	}
	//*/
	/*
	public override bool Equals(object obj)
	{
		Time Other = (Time)obj;
		if (Other == null) return false;
		Console.WriteLine("Equals Called");
		return (Other.hour == hour && Other.min == min && Other.sec == sec);
	}
	//*/
}


class CSTest
{
	static void Main()
	{
		Time A = new Time(1, 2, 3);
		Time B = null;
		Console.WriteLine(A.Equals(B));
	}
}
