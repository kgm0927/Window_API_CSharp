﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Emgu.CV;
using Emgu.CV.Structure;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        Image<Bgr, byte> _imgInput;
        public Form1()
        {
            InitializeComponent();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();

            if(ofd.ShowDialog() == DialogResult.OK)
            {
                _imgInput = new Image<Bgr, byte>(ofd.FileName);
                imageBox1.Image = _imgInput;
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("종료 하시겠습니까?", "System Message", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void cannyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ApplyCanny();
            return;
        }

        public void ApplyCanny(double thresh = 50.0, double threshLink = 20.0)
        {
            if (_imgInput == null)
            {
                return;
            }
            Image<Gray, byte> _imgCanny = new Image<Gray, byte>(_imgInput.Width, _imgInput.Height, new Gray(0));

            _imgCanny = _imgInput.Canny(thresh, threshLink);
            imageBox1.Image = _imgCanny;
            return;
        }
        private void sobelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_imgInput == null)
            {
                return;
            }
            Image<Gray, byte> _imgGray = _imgInput.Convert<Gray, byte>();
            Image<Gray, float> _imgSobel = new Image<Gray, float>(_imgInput.Width, _imgInput.Height, new Gray(0));
            
            _imgSobel = _imgGray.Sobel(1,0,3).Add(_imgGray.Sobel(0,1,3)).AbsDiff(new Gray(0.0));
            imageBox1.Image = _imgSobel.Convert<Gray, byte>();
            return;
        }


        private void laplacianToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_imgInput == null)
            {
                return;
            }
            Image<Gray, byte> _imgGray = _imgInput.Convert<Gray, byte>();
            Image<Gray, float> _imgLaplacian = new Image<Gray, float>(_imgInput.Width, _imgInput.Height, new Gray(0));

            _imgLaplacian = _imgGray.Laplace(7).AbsDiff(new Gray(0.0));
            imageBox1.Image = _imgLaplacian.Convert<Gray, byte>();
            return;
        }

        private void cannyParametersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CannyParameters cp = new WindowsFormsApplication1.CannyParameters(this);
            cp.StartPosition = FormStartPosition.CenterParent;
            cp.Show();
        }
    }
}
